{-# LANGUAGE LambdaCase #-}

-- Expression trees and evaluation

module Exp where

data Exp
  = EInt   Integer
  | EPlus  Exp Exp
  | EMinus Exp Exp
  | ETimes Exp Exp
  | EDiv   Exp Exp

eval :: Exp -> Integer
eval = \case
  EInt i -> i
  EPlus  e1 e2 -> eval e1 + eval e2
  EMinus e1 e2 -> eval e1 - eval e2
  ETimes e1 e2 -> eval e1 * eval e2
  EDiv   e1 e2 -> eval e1 `div` eval e2
