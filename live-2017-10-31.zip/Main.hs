import Exp
import CalcLexer  ( alexScanTokens )
import CalcParser ( calcParser )

main :: IO ()
main = do
  putStrLn "PLT Calculator (C) 2017 Chalmers/GU"
  -- let e = EPlus (EInt 5) (ETimes (EInt 6) (EInt 7))
  inp <- getContents
  let e = calcParser (alexScanTokens inp)
  print $ eval e
