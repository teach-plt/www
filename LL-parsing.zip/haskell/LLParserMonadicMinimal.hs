
{-# LANGUAGE LambdaCase #-}

-- Grammar:

-- S  ::= Integer S';
-- S' ::= ;
-- S' ::= "+" S;
-- S' ::= "*" P S';
-- P  ::= Integer P' ;
-- P' ::= ;
-- P' ::= "*" P ;

import Control.Monad.State
import Control.Monad.Trans.Maybe
import Data.List

data Token
  = TInt Integer
  | TPlus
  | TTimes

type Parse = MaybeT (State [Token])

runParser :: Parse a -> [Token] -> Maybe a
runParser p ts = evalState (runMaybeT p) ts

-- | Look ahead a the next token, if it exists.

peek :: Parse (Maybe Token)
peek = fmap fst . uncons <$> get

-- | Skip the next token.

skip :: Parse ()
skip = modify tail

-- | Take the next token, if it exists.

next :: Parse (Maybe Token)
next = peek <* skip

-- | Parse failure.

failure :: Parse a
failure = mzero

type Sum = [Prod]
type Prod = [Integer]

parseS :: Parse Sum
parseS = next >>= \case
  Just (TInt i) -> parseS' [i]
  _ -> failure

parseS' :: Prod -> Parse Sum
parseS' p = next >>= \case
  Nothing     -> return [p]
  Just TPlus  -> (p :) <$> parseS
  Just TTimes -> parseS' . (p ++) =<< parseP
  _ -> failure

parseP :: Parse Prod
parseP = next >>= \case
  Just (TInt i) -> (i:) <$> parseP'
  _ -> failure

parseP' :: Parse Prod
parseP' = peek >>= \case
  Just TTimes -> skip *> parseP
  _ -> return []

yes = runParser parseS [TInt 1, TPlus, TInt 2, TTimes, TInt 3, TPlus, TInt 4]
no  = runParser parseS [TInt 1, TPlus, TPlus, TInt 2]
