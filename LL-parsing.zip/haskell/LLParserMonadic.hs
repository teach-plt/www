
{-# LANGUAGE LambdaCase #-}

-- Grammar:

-- S  ::= Integer S';
-- S' ::= ;
-- S' ::= "+" S;
-- S' ::= "*" P S';
-- P  ::= Integer P' ;
-- P' ::= ;
-- P' ::= "*" P ;

import Control.Monad.State
import Control.Monad.Trans.Maybe

data Token
  = TInt Integer
  | TPlus
  | TTimes

type Parse = MaybeT (State [Token])

runParser :: Parse a -> [Token] -> Maybe a
runParser p ts = evalState (runMaybeT p) ts

-- | Look ahead a the next token, if it exists.

peek :: Parse (Maybe Token)
peek = do
  tokens <- get
  case tokens of
    []      -> return Nothing
    (t : _) -> return $ Just t

-- | Skip the next token.

skip :: Parse ()
skip = modify tail

-- | Take the next token, if it exists.

next :: Parse (Maybe Token)
next = do
  tokens <- get
  case tokens of
    [] -> return Nothing
    (t : rest) -> do
      put rest
      return $ Just t

next' = do
  t <- peek
  skip
  return t

-- | Parse failure.

failure :: Parse a
failure = mzero


type Sum = [Prod]
type Prod = [Integer]

parseS :: Parse Sum
parseS = next >>= \case
  Just (TInt i) -> parseS' [i]
  _ -> failure

parseS' :: Prod -> Parse Sum
parseS' p = next >>= \case
  Nothing -> return [p]

  Just TPlus -> do
    s <- parseS
    return (p : s)

  Just TTimes -> do
    p' <- parseP
    parseS' (p ++ p')

  _ -> failure

parseP, parseP' :: Parse Prod

parseP = next >>= \case

  Just (TInt i) -> do
    p <- parseP'
    return (i:p)

  _ -> failure

parseP' = peek >>= \case
  Just TTimes -> do
    skip
    parseP
  _ -> return []

yes = runParser parseS [TInt 1, TPlus, TInt 2, TTimes, TInt 3, TPlus, TInt 4]
no  = runParser parseS [TInt 1, TPlus, TPlus, TInt 2]
