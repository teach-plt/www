{-# LANGUAGE LambdaCase #-}

-- Grammar:

-- S  ::= Integer S';
-- S' ::= ;
-- S' ::= "+" S;
-- S' ::= "*" P S';
-- P  ::= Integer P' ;
-- P' ::= ;
-- P' ::= "*" P ;

data Token
  = TInt
  | TPlus
  | TTimes

acceptS, acceptS' :: [Token] -> Bool

acceptS = \case
  TInt : rest -> acceptS' rest
  _ -> False

acceptS' = \case
  []            -> True
  TPlus  : rest -> acceptS rest
  TTimes : rest -> let (ok, rest') = acceptP rest
                   in  ok && acceptS' rest'
  _ -> False

acceptP, acceptP' :: [Token] -> (Bool, [Token])

acceptP = \case
  TInt : rest -> acceptP' rest
  _ -> (False, [])

acceptP' = \case
  TTimes : rest -> acceptP rest
  inp -> (True, inp)

yes = acceptS [TInt, TPlus, TInt, TTimes, TInt]
no  = acceptS [TInt, TPlus, TPlus, TInt]
