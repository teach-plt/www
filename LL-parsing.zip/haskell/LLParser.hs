{-# LANGUAGE LambdaCase #-}

-- Grammar:

-- S  ::= Integer S';
-- S' ::= ;
-- S' ::= "+" S;
-- S' ::= "*" P S';
-- P  ::= Integer P' ;
-- P' ::= ;
-- P' ::= "*" P ;

data Token
  = TInt Integer
  | TPlus
  | TTimes

type Sum = [Prod]
type Prod = [Integer]

parseS :: [Token] -> Maybe Sum
parseS = \case
  TInt i : rest -> parseS' [i] rest
  _ -> Nothing

parseS' :: Prod -> [Token] -> Maybe Sum
parseS' p = \case
  []            -> return [p]

  TPlus  : rest -> do
    s <- parseS rest
    return (p : s)

  TTimes : rest -> do
    (p', rest') <- parseP rest
    parseS' (p ++ p') rest'
  _ -> Nothing

parseP, parseP' :: [Token] -> Maybe (Prod, [Token])

parseP = \case

  TInt i : rest -> do
    (p, rest') <- parseP' rest
    return (i:p, rest')

  _ -> Nothing

parseP' = \case
  TTimes : rest -> parseP rest
  inp -> return ([], inp)

yes = parseS [TInt 1, TPlus, TInt 2, TTimes, TInt 3, TPlus, TInt 4]
no  = parseS [TInt 1, TPlus, TPlus, TInt 2]
