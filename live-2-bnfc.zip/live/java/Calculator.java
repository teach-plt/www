import java_cup.runtime.*;
import Calc.*;
import Calc.Absyn.*;
import java.io.*;

public class Calculator {

    public static void main (String args[]) throws Exception {

	Calc.Absyn.Exp e = (new parser(new Yylex(System.in))).pExp();
        System.out.println(e.accept(new EvalVisitor(), null));
    }
}
