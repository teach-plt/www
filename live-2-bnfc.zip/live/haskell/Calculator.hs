import Calc.Abs  (Exp(..))
import Calc.Par  (myLexer, pExp)
import Calc.ErrM (Err(Ok, Bad))

parse :: String -> Exp
parse s = case pExp (myLexer s) of
  Ok  e   -> e
  Bad err -> error err

eval :: Exp -> Integer
eval e = case e of
  EInt i     -> i
  EAdd e1 e2 -> eval e1 + eval e2
  ESub e1 e2 -> eval e1 - eval e2
  EMul e1 e2 -> eval e1 * eval e2
  EDiv e1 e2 -> eval e1 `div` eval e2



e1 = EAdd (EInt 5) (EMul (EInt 6) (EInt 7))
test1 = eval e1

calc :: String -> String
calc = show . eval . parse

main = do
  interact calc
  putStrLn ""
