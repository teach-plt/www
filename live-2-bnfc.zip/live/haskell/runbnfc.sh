#!/bin/sh

bnfc --haskell -d -m ../Calc.cf

#EOF
