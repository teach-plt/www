import cmm.Absyn.*;
import java.util.*;
import java.util.Map;

public class TypeChecker {

    // Signature
    Map<String,FunType> sig;

    public void typecheck(Program p) {

        // Pass1: make a signature of function types.
        sig = new TreeMap<String,FunType> ();
        for (Def def : ((PDefs)p).listdef_) {
          sig.put(((DFun)def).id_, new FunType(((DFun)def).type_, ((DFun)def).listarg_));
        }

        // Pass2: visit all the function definitions.

        // Check that "main" exists and the correct type.


        throw new TypeException("Not yet a typechecker");
    }

}
