import cmm.Absyn.*;
import java.util.*;

public class FunType {

    // Type of value the function returns
    public final Type funResultType;

    // Type of the function arguments
    public final List<Arg> funArgs;

    public FunType (Type funResultType, List<Arg> funArgs) {
      this.funResultType = funResultType;
      this.funArgs       = funArgs;
    }

}
