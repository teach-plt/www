import calc.Absyn.*;

class Eval {

  public Integer eval(Exp exp) {
    return null;
  }

  public static void main (String[] args) {

    // 5 + 6 * 7
    calc.Absyn.Exp e =
      new calc.Absyn.EAdd
        ( new calc.Absyn.EInt (5)
        , new calc.Absyn.EMul
          ( new calc.Absyn.EInt (6)
          , new calc.Absyn.EInt (7)));

    Integer value = new Eval().eval(e);

    System.out.println (value);

  }

/*

  e5 = EInt (5)
  e6 = EInt (6)
  e7 = EInt (7)
  e67  = EMul (e6, e7)
  e567 = EAdd (e5, e67)

*/

}
