{-# LANGUAGE BlockArguments  #-}
{-# LANGUAGE PatternSynonyms #-}

module Main where

import Control.Exception (catch, IOException)
import Control.Monad     (unless)
import System.IO         (stdout, hSetBuffering, pattern NoBuffering)

import Calc.Abs          (Exp(..))         -- abstract syntax
import Calc.Par          (pExp, myLexer)   -- parser

-- | Evaluate an expression.

eval :: Exp -> Integer
eval e = case e of
  EAdd e1 e2 -> eval e1 + eval e2
  ESub e1 e2 -> eval e1 - eval e2
  EMul e1 e2 -> eval e1 * eval e2
  EDiv e1 e2 -> eval e1 `div` eval e2
  EInt i     -> i

-- | Parse and evaluate.

calc :: String -> String
calc s = case pExp (myLexer s) of
  Right exp -> show (eval exp)
  Left  msg -> "Parse failed: " ++ msg

-- | Read-Eval-Print-Loop.

repl :: String -> (String -> String) -> IO ()
repl prompt interpret = do
  putStr prompt
  s <- getLine `catch` \ (_ :: IOError) -> return ""
  unless (null s) do
    putStrLn (interpret s)
    repl prompt interpret

-- | Entrypoint.

main :: IO ()
main = do
  hSetBuffering stdout NoBuffering
  repl "calc> " calc
