{-# LANGUAGE LambdaCase #-}
{-# OPTIONS_GHC -Wno-unused-imports #-} -- Turn off unused import warning off in stub

module TypeChecker where

import Control.Monad
import Control.Monad.Except

import Data.Map (Map)
import qualified Data.Map as Map

import CMM.Abs
import CMM.Print (printTree)

import qualified TypedSyntax as T

type AnnotatedProgram = T.Program
type TypeError = String

type M = Either TypeError

type Context = [Block]
type Block = Map Id Type

typecheck :: Program -> M T.Program
typecheck (PDefs defs) = do
  -- Pass 1: create signature
  -- Pass 2: check definitions
  defs' <- mapM checkDef defs
  -- Check for main
  return $ T.PDefs defs'

checkDef :: Def -> M T.Def
checkDef (DFun t f args ss) = do
  -- unless (null args) $ nyi $ "checking arguments"
  -- check arguments, error out on duplicates
  block <- checkArgs args
  ss' <- mapM (checkStm [block]) ss
  return $ T.DFun t f args ss'

checkArgs :: [Arg] -> M Block
checkArgs args = do
  -- check for duplicates
  -- make block
  return $ Map.fromList $ map (\ (ADecl t x) -> (x, t)) args

checkStm :: Context -> Stm -> M T.Stm
checkStm cxt = \case
  SReturn e -> do
    e' <- checkExp cxt e
    return $ T.SReturn e'
  s -> nyi $ "checking statement"

checkExp :: Context -> Exp -> M T.Exp
checkExp cxt = \case
  EInt i -> return $ T.EInt i
  e -> nyi $ "checking expression"

nyi :: String -> M a
nyi msg = throwError $ unwords [ "not yet implemented:", msg ]
