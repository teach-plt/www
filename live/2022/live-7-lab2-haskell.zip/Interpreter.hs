{-# LANGUAGE LambdaCase #-}
{-# OPTIONS_GHC -Wno-unused-imports #-} -- Turn off unused import warning off in stub

module Interpreter where

import Control.Monad

import Data.Map (Map)
import qualified Data.Map as Map

import TypedSyntax

data Value
  = VInt Integer
  | VDouble Double
  | VBool Bool
  | VNull

type Env = [Block]
Type Block = Map Id Value

printValue :: Value -> String
printValue = \case
  VInt i    -> show i
  VDouble d -> show d
  VBool b   -> show b
  VNull     -> "undefined value"

interpret :: Program -> IO ()
interpret (PDefs defs) = do
  -- Preparation: create the signature which maps functions names to their definition
  -- Find the main function.  We can assume it exists.
  let (DFun _ _ _ ss) = head $ filter (\ (DFun _ f _ ss) -> f == Id "main") defs
  -- Execute its statements
  mapM_ exec ss

exec :: Stm -> IO ()
exec = \case
  SReturn e -> do
    v <- eval e
    putStrLn $ unwords ["main returned", printValue v]
  s -> nyi $ "exec"

eval :: Exp -> IO Value
eval = \case
  EInt i -> return $ VInt i
  e -> nyi $ "eval"

nyi msg = error $ unwords [ "not yet implemented", msg ]
