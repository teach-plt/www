{-# LANGUAGE LambdaCase #-}

module Exp where

data Exp
  = EInt   Integer
  | EPlus  Exp Exp
  | EMinus Exp Exp
  | ETimes Exp Exp
  deriving Show

eval :: Exp -> Integer
eval = \case
  EInt i -> i
  EPlus  e1 e2 -> eval e1 + eval e2
  EMinus e1 e2 -> eval e1 - eval e2
  ETimes e1 e2 -> eval e1 * eval e2
