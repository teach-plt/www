import Exp
import CalcLexer  ( alexScanTokens )
import CalcParser ( calcParser )

main :: IO ()
main = do
  res <- calcParser .  alexScanTokens <$> getContents
  print res
  print $ eval res
