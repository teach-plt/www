{-# LANGUAGE LambdaCase #-}

import Calc.Abs  ( Exp(..) )
import Calc.Par  ( pExp, myLexer )

eval :: Exp -> Integer
eval = \case
  EInt   i     -> i
  EPlus  e1 e2 -> eval e1 + eval e2
  EMinus e1 e2 -> eval e1 - eval e2
  ETimes e1 e2 -> eval e1 * eval e2
  EDiv   e1 e2 -> eval e1 `div` eval e2

main :: IO ()
main = do
  -- Read from stdin, lex, parse
  res <- pExp . myLexer <$> getContents
  case res of
    -- Parse error? Print to user.
    Left err -> putStrLn err
    -- Otherwise, evaluate expression and print result.
    Right  e -> print $ eval e
