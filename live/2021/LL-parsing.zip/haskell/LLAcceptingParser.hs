{-# LANGUAGE LambdaCase #-}

-- | Recursive descent (LL) parser that accepts input or not.

-- Original grammar:

-- S ::= S + P
-- S ::= P
-- P ::= P * Integer
-- P ::= Integer

-- Left-factored grammar:

-- S  ::= Integer S';
-- S' ::= ;
-- S' ::= "+" S;
-- S' ::= "*" P S';
-- P  ::= Integer P' ;
-- P' ::= ;
-- P' ::= "*" P ;

data Token
  = TInt Integer
  | TPlus
  | TTimes

-- Accepting parser, entrypoint: no left over tokens.

acceptS :: [Token] -> Bool
acceptS = \case
  TInt i : rest -> acceptS' rest
  _ -> False

acceptS' :: [Token] -> Bool
acceptS' = \case
  []            -> True
  TPlus  : rest -> acceptS rest
  TTimes : rest -> let (ok, rest') = acceptP rest
                   in  ok && acceptS' rest'
  _ -> False

-- Accepting parser, general form: returns remaining tokens.

acceptP :: [Token] -> (Bool, [Token])
acceptP = \case
  TInt i : rest -> acceptP' rest
  _ -> (False, [])

acceptP' :: [Token] -> (Bool, [Token])
acceptP' = \case
  TTimes : rest -> acceptP rest
  inp -> (True, inp)

-- Test

yes = acceptS [TInt 5, TPlus, TInt 6, TTimes, TInt 7]
no  = acceptS [TInt 5, TPlus, TPlus, TInt 6]
