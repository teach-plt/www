abstract class Token {
  abstract public String toString();
}

class TInt extends Token {
  public final Integer integer;
  public TInt (Integer i) { integer = i; }
  public String toString() { return integer.toString(); }
}

class TPlus extends Token {
  public String toString() { return "+"; }
}

class TTimes extends Token {
  public String toString() { return "*"; }
}
