import java.util.*;

// Grammar:

// Sum      ::= Integer SumRest;
// SumRest  ::= ;
// SumRest  ::= "+" Sum;
// SumRest  ::= "*" Prod SumRest;
// Prod     ::= Integer ProdRest ;
// ProdRest ::= ;
// ProdRest ::= "*" Prod ;

class LLParse {

  private LinkedList<Token> tokens;

  public LLParse (LinkedList<Token> t) { tokens = t; }

  // Parse a sum.
  // Sum ::= Integer SumRest;
  public Integer parseSum() throws ParseException {
    Token t = tokens.pollFirst();
    if (t == null) throw new ParseException("expected Sum, but input is empty");
    if (t instanceof TInt) {
      Integer s = parseSumRest (((TInt)t).integer);
      return s;
    } else throw new ParseException("expected Sum, found " + t);
  }

  // Parse the rest of a sum.
  // SumRest ::= ;
  // SumRest ::= "+" Sum;
  // SumRest ::= "*" Prod SumRest;
  public Integer parseSumRest(Integer p) throws ParseException {
    Token t = tokens.pollFirst();
    if (t == null) return p;
    if (t instanceof TPlus) {
      Integer s = parseSum();
      return p + s;
    } else if (t instanceof TTimes) {
      Integer p1 = parseProd();
      Integer s = parseSumRest (p * p1);
      return s;
    } else throw new ParseException("expected SumRest, found " + t);
  }

  // Parse a product.
  // Prod ::= Integer ProdRest ;
  public Integer parseProd() throws ParseException {
    Token t = tokens.pollFirst();
    if (t == null) throw new ParseException("expected Prod, but the input is empty");
    if (t instanceof TInt) {
      Integer p = parseProdRest();
      return ((TInt)t).integer * p;
    } else throw new ParseException("expected Prod, found " + t);
  }

  // Parse the rest of a product.
  // ProdRest ::= ;
  // ProdRest ::= "*" Prod ;
  public Integer parseProdRest() throws ParseException {
    Token t = tokens.peekFirst();
    if (t != null && t instanceof TTimes) {
      tokens.removeFirst();
      Integer p = parseProd();
      return p;
    } else return 1;
  }

  public static void main (String[] args) {
    LinkedList<Token> ts = new LinkedList();
    // 1 + 2 * 3 + 4
    ts.add(new TInt(1));
    ts.add(new TPlus());
    ts.add(new TInt(2));
    ts.add(new TTimes());
    ts.add(new TInt(3));
    ts.add(new TPlus());
    ts.add(new TInt(4));
    try {
      Integer s = new LLParse(ts).parseSum();
      System.out.println ("Result: " + s);
    } catch (ParseException e) {
      System.err.println ("Parse error: " + e.getMessage());
    }
  }
}
