import calc.Absyn.*;

class Eval {

  public static Integer eval(Exp exp) {
    if      (exp instanceof EInt) { return ((EInt)exp).integer_; }
    else if (exp instanceof EAdd) { return eval(((EAdd)exp).exp_1) + eval (((EAdd)exp).exp_2); }
    else if (exp instanceof EMul) { return eval(((EAdd)exp).exp_1) * eval (((EAdd)exp).exp_2); }
    else return(-9999999); // TODO
  }

  public static void main (String[] args) {

    // 5 + 6 * 7
    calc.Absyn.Exp e =
      new calc.Absyn.EAdd
        ( new calc.Absyn.EInt (5)
        , new calc.Absyn.EMul
          ( new calc.Absyn.EInt (6)
          , new calc.Absyn.EInt (7)));

    Integer value = eval(e);

    System.out.println (value);

  }

/*

  e5 = EInt (5)
  e6 = EInt (6)
  e7 = EInt (7)
  e67  = EMul (e6, e7)
  e567 = EAdd (e5, e67)

*/

}
