// Calculator in Java

import calc.parser;
import calc.Yylex;
import calc.Absyn.*;
import java.io.*;

public class Calc
{
  Yylex l;
  parser p;

  public Calc(String[] args)
  {
    try
    {
      Reader input;
      if (args.length == 0) input = new InputStreamReader(System.in);
      else input = new FileReader(args[0]);
      l = new Yylex(input);
    }
    catch(IOException e)
    {
      System.err.println("Error: File not found: " + args[0]);
      System.exit(1);
    }
    p = new parser(l, l.getSymbolFactory());
  }

  public calc.Absyn.Exp parse() throws Exception
  {
    return p.pExp();
  }

  public static Integer eval (Exp e) {
    switch (e) {
      case EInt   p -> { return p.integer_; }
      case EPlus  p -> { return eval(p.exp_1) + eval(p.exp_2); }
      case EMinus p -> { return eval(p.exp_1) - eval(p.exp_2); }
      case ETimes p -> { return eval(p.exp_1) * eval(p.exp_2); }
      case EDiv   p -> { return eval(p.exp_1) / eval(p.exp_2); }
      default -> { return 0; }
    }
  }

  public static void main(String args[]) throws Exception
  {
    Calc t = new Calc(args);
    try
    {
      calc.Absyn.Exp e = t.parse();
      int i = eval(e);
      System.out.println(i);
    }
    catch(Throwable e)
    {
      System.err.println("At line " + String.valueOf(t.l.line_num()) + ", near \"" + t.l.buff() + "\" :");
      System.err.println("     " + e.getMessage());
      System.exit(1);
    }
  }
}
