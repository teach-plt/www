package CMM;
import CMM.Absyn.*;

public class PrettyPrinter
{
  //For certain applications increasing the initial size of the buffer may improve performance.
  private static final int INITIAL_BUFFER_SIZE = 128;
  private static final int INDENT_WIDTH = 2;
  //You may wish to change the parentheses used in precedence.
  private static final String _L_PAREN = new String("(");
  private static final String _R_PAREN = new String(")");
  //You may wish to change render
  private static void render(String s)
  {
    if (s.equals("{"))
    {
       buf_.append("\n");
       indent();
       buf_.append(s);
       _n_ = _n_ + INDENT_WIDTH;
       buf_.append("\n");
       indent();
    }
    else if (s.equals("(") || s.equals("["))
       buf_.append(s);
    else if (s.equals(")") || s.equals("]"))
    {
       backup();
       buf_.append(s);
       buf_.append(" ");
    }
    else if (s.equals("}"))
    {
       int t;
       _n_ = _n_ - INDENT_WIDTH;
       for(t=0; t<INDENT_WIDTH; t++) {
         backup();
       }
       buf_.append(s);
       buf_.append("\n");
       indent();
    }
    else if (s.equals(","))
    {
       backup();
       buf_.append(s);
       buf_.append(" ");
    }
    else if (s.equals(";"))
    {
       backup();
       buf_.append(s);
       buf_.append("\n");
       indent();
    }
    else if (s.equals("")) return;
    else
    {
       buf_.append(s);
       buf_.append(" ");
    }
  }


  //  print and show methods are defined for each category.
  public static String print(CMM.Absyn.Program foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.Program foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.Def foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.Def foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.ListDef foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.ListDef foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.Arg foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.Arg foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.ListArg foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.ListArg foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.Stm foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.Stm foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.ListStm foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.ListStm foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.Exp foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.Exp foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.ListExp foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.ListExp foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.BoolLit foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.BoolLit foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.Type foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.Type foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String print(CMM.Absyn.ListId foo)
  {
    pp(foo, 0);
    trim();
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  public static String show(CMM.Absyn.ListId foo)
  {
    sh(foo);
    String temp = buf_.toString();
    buf_.delete(0,buf_.length());
    return temp;
  }
  /***   You shouldn't need to change anything beyond this point.   ***/

  private static void pp(CMM.Absyn.Program foo, int _i_)
  {
    if (foo instanceof CMM.Absyn.PDefs)
    {
       CMM.Absyn.PDefs _pdefs = (CMM.Absyn.PDefs) foo;
       if (_i_ > 0) render(_L_PAREN);
       pp(_pdefs.listdef_, 0);
       if (_i_ > 0) render(_R_PAREN);
    }
  }

  private static void pp(CMM.Absyn.Def foo, int _i_)
  {
    if (foo instanceof CMM.Absyn.DFun)
    {
       CMM.Absyn.DFun _dfun = (CMM.Absyn.DFun) foo;
       if (_i_ > 0) render(_L_PAREN);
       pp(_dfun.type_, 0);
       pp(_dfun.id_, 0);
       render("(");
       pp(_dfun.listarg_, 0);
       render(")");
       render("{");
       pp(_dfun.liststm_, 0);
       render("}");
       if (_i_ > 0) render(_R_PAREN);
    }
  }

  private static void pp(CMM.Absyn.ListDef foo, int _i_)
  {
     for (java.util.Iterator<Def> it = foo.iterator(); it.hasNext();)
     {
       pp(it.next(), _i_);
       if (it.hasNext()) {
         render("");
       } else {
         render("");
       }
     }  }

  private static void pp(CMM.Absyn.Arg foo, int _i_)
  {
    if (foo instanceof CMM.Absyn.ADecl)
    {
       CMM.Absyn.ADecl _adecl = (CMM.Absyn.ADecl) foo;
       if (_i_ > 0) render(_L_PAREN);
       pp(_adecl.type_, 0);
       pp(_adecl.id_, 0);
       if (_i_ > 0) render(_R_PAREN);
    }
  }

  private static void pp(CMM.Absyn.ListArg foo, int _i_)
  {
     for (java.util.Iterator<Arg> it = foo.iterator(); it.hasNext();)
     {
       pp(it.next(), _i_);
       if (it.hasNext()) {
         render(",");
       } else {
         render("");
       }
     }  }

  private static void pp(CMM.Absyn.Stm foo, int _i_)
  {
    if (foo instanceof CMM.Absyn.SExp)
    {
       CMM.Absyn.SExp _sexp = (CMM.Absyn.SExp) foo;
       if (_i_ > 0) render(_L_PAREN);
       pp(_sexp.exp_, 0);
       render(";");
       if (_i_ > 0) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.SInit)
    {
       CMM.Absyn.SInit _sinit = (CMM.Absyn.SInit) foo;
       if (_i_ > 0) render(_L_PAREN);
       pp(_sinit.type_, 0);
       pp(_sinit.id_, 0);
       render("=");
       pp(_sinit.exp_, 0);
       render(";");
       if (_i_ > 0) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.SWhile)
    {
       CMM.Absyn.SWhile _swhile = (CMM.Absyn.SWhile) foo;
       if (_i_ > 0) render(_L_PAREN);
       render("while");
       render("(");
       pp(_swhile.exp_, 0);
       render(")");
       pp(_swhile.stm_, 0);
       if (_i_ > 0) render(_R_PAREN);
    }
  }

  private static void pp(CMM.Absyn.ListStm foo, int _i_)
  {
     for (java.util.Iterator<Stm> it = foo.iterator(); it.hasNext();)
     {
       pp(it.next(), _i_);
       if (it.hasNext()) {
         render("");
       } else {
         render("");
       }
     }  }

  private static void pp(CMM.Absyn.Exp foo, int _i_)
  {
    if (foo instanceof CMM.Absyn.EBool)
    {
       CMM.Absyn.EBool _ebool = (CMM.Absyn.EBool) foo;
       if (_i_ > 6) render(_L_PAREN);
       pp(_ebool.boollit_, 0);
       if (_i_ > 6) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.EInt)
    {
       CMM.Absyn.EInt _eint = (CMM.Absyn.EInt) foo;
       if (_i_ > 6) render(_L_PAREN);
       pp(_eint.integer_, 0);
       if (_i_ > 6) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.EDouble)
    {
       CMM.Absyn.EDouble _edouble = (CMM.Absyn.EDouble) foo;
       if (_i_ > 6) render(_L_PAREN);
       pp(_edouble.double_, 0);
       if (_i_ > 6) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.EId)
    {
       CMM.Absyn.EId _eid = (CMM.Absyn.EId) foo;
       if (_i_ > 6) render(_L_PAREN);
       pp(_eid.id_, 0);
       if (_i_ > 6) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.EApp)
    {
       CMM.Absyn.EApp _eapp = (CMM.Absyn.EApp) foo;
       if (_i_ > 6) render(_L_PAREN);
       pp(_eapp.id_, 0);
       render("(");
       pp(_eapp.listexp_, 0);
       render(")");
       if (_i_ > 6) render(_R_PAREN);
    }
  }

  private static void pp(CMM.Absyn.ListExp foo, int _i_)
  {
     for (java.util.Iterator<Exp> it = foo.iterator(); it.hasNext();)
     {
       pp(it.next(), _i_);
       if (it.hasNext()) {
         render(",");
       } else {
         render("");
       }
     }  }

  private static void pp(CMM.Absyn.BoolLit foo, int _i_)
  {
    if (foo instanceof CMM.Absyn.LTrue)
    {
       CMM.Absyn.LTrue _ltrue = (CMM.Absyn.LTrue) foo;
       if (_i_ > 0) render(_L_PAREN);
       render("true");
       if (_i_ > 0) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.LFalse)
    {
       CMM.Absyn.LFalse _lfalse = (CMM.Absyn.LFalse) foo;
       if (_i_ > 0) render(_L_PAREN);
       render("false");
       if (_i_ > 0) render(_R_PAREN);
    }
  }

  private static void pp(CMM.Absyn.Type foo, int _i_)
  {
    if (foo instanceof CMM.Absyn.Type_bool)
    {
       CMM.Absyn.Type_bool _type_bool = (CMM.Absyn.Type_bool) foo;
       if (_i_ > 0) render(_L_PAREN);
       render("bool");
       if (_i_ > 0) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.Type_int)
    {
       CMM.Absyn.Type_int _type_int = (CMM.Absyn.Type_int) foo;
       if (_i_ > 0) render(_L_PAREN);
       render("int");
       if (_i_ > 0) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.Type_double)
    {
       CMM.Absyn.Type_double _type_double = (CMM.Absyn.Type_double) foo;
       if (_i_ > 0) render(_L_PAREN);
       render("double");
       if (_i_ > 0) render(_R_PAREN);
    }
    else     if (foo instanceof CMM.Absyn.Type_void)
    {
       CMM.Absyn.Type_void _type_void = (CMM.Absyn.Type_void) foo;
       if (_i_ > 0) render(_L_PAREN);
       render("void");
       if (_i_ > 0) render(_R_PAREN);
    }
  }

  private static void pp(CMM.Absyn.ListId foo, int _i_)
  {
     for (java.util.Iterator<String> it = foo.iterator(); it.hasNext();)
     {
       pp(it.next(), _i_);
       if (it.hasNext()) {
         render(",");
       } else {
         render("");
       }
     }  }


  private static void sh(CMM.Absyn.Program foo)
  {
    if (foo instanceof CMM.Absyn.PDefs)
    {
       CMM.Absyn.PDefs _pdefs = (CMM.Absyn.PDefs) foo;
       render("(");
       render("PDefs");
       render("[");
       sh(_pdefs.listdef_);
       render("]");
       render(")");
    }
  }

  private static void sh(CMM.Absyn.Def foo)
  {
    if (foo instanceof CMM.Absyn.DFun)
    {
       CMM.Absyn.DFun _dfun = (CMM.Absyn.DFun) foo;
       render("(");
       render("DFun");
       sh(_dfun.type_);
       sh(_dfun.id_);
       render("[");
       sh(_dfun.listarg_);
       render("]");
       render("[");
       sh(_dfun.liststm_);
       render("]");
       render(")");
    }
  }

  private static void sh(CMM.Absyn.ListDef foo)
  {
     for (java.util.Iterator<Def> it = foo.iterator(); it.hasNext();)
     {
       sh(it.next());
       if (it.hasNext())
         render(",");
     }
  }

  private static void sh(CMM.Absyn.Arg foo)
  {
    if (foo instanceof CMM.Absyn.ADecl)
    {
       CMM.Absyn.ADecl _adecl = (CMM.Absyn.ADecl) foo;
       render("(");
       render("ADecl");
       sh(_adecl.type_);
       sh(_adecl.id_);
       render(")");
    }
  }

  private static void sh(CMM.Absyn.ListArg foo)
  {
     for (java.util.Iterator<Arg> it = foo.iterator(); it.hasNext();)
     {
       sh(it.next());
       if (it.hasNext())
         render(",");
     }
  }

  private static void sh(CMM.Absyn.Stm foo)
  {
    if (foo instanceof CMM.Absyn.SExp)
    {
       CMM.Absyn.SExp _sexp = (CMM.Absyn.SExp) foo;
       render("(");
       render("SExp");
       sh(_sexp.exp_);
       render(")");
    }
    if (foo instanceof CMM.Absyn.SInit)
    {
       CMM.Absyn.SInit _sinit = (CMM.Absyn.SInit) foo;
       render("(");
       render("SInit");
       sh(_sinit.type_);
       sh(_sinit.id_);
       sh(_sinit.exp_);
       render(")");
    }
    if (foo instanceof CMM.Absyn.SWhile)
    {
       CMM.Absyn.SWhile _swhile = (CMM.Absyn.SWhile) foo;
       render("(");
       render("SWhile");
       sh(_swhile.exp_);
       sh(_swhile.stm_);
       render(")");
    }
  }

  private static void sh(CMM.Absyn.ListStm foo)
  {
     for (java.util.Iterator<Stm> it = foo.iterator(); it.hasNext();)
     {
       sh(it.next());
       if (it.hasNext())
         render(",");
     }
  }

  private static void sh(CMM.Absyn.Exp foo)
  {
    if (foo instanceof CMM.Absyn.EBool)
    {
       CMM.Absyn.EBool _ebool = (CMM.Absyn.EBool) foo;
       render("(");
       render("EBool");
       sh(_ebool.boollit_);
       render(")");
    }
    if (foo instanceof CMM.Absyn.EInt)
    {
       CMM.Absyn.EInt _eint = (CMM.Absyn.EInt) foo;
       render("(");
       render("EInt");
       sh(_eint.integer_);
       render(")");
    }
    if (foo instanceof CMM.Absyn.EDouble)
    {
       CMM.Absyn.EDouble _edouble = (CMM.Absyn.EDouble) foo;
       render("(");
       render("EDouble");
       sh(_edouble.double_);
       render(")");
    }
    if (foo instanceof CMM.Absyn.EId)
    {
       CMM.Absyn.EId _eid = (CMM.Absyn.EId) foo;
       render("(");
       render("EId");
       sh(_eid.id_);
       render(")");
    }
    if (foo instanceof CMM.Absyn.EApp)
    {
       CMM.Absyn.EApp _eapp = (CMM.Absyn.EApp) foo;
       render("(");
       render("EApp");
       sh(_eapp.id_);
       render("[");
       sh(_eapp.listexp_);
       render("]");
       render(")");
    }
  }

  private static void sh(CMM.Absyn.ListExp foo)
  {
     for (java.util.Iterator<Exp> it = foo.iterator(); it.hasNext();)
     {
       sh(it.next());
       if (it.hasNext())
         render(",");
     }
  }

  private static void sh(CMM.Absyn.BoolLit foo)
  {
    if (foo instanceof CMM.Absyn.LTrue)
    {
       CMM.Absyn.LTrue _ltrue = (CMM.Absyn.LTrue) foo;
       render("LTrue");
    }
    if (foo instanceof CMM.Absyn.LFalse)
    {
       CMM.Absyn.LFalse _lfalse = (CMM.Absyn.LFalse) foo;
       render("LFalse");
    }
  }

  private static void sh(CMM.Absyn.Type foo)
  {
    if (foo instanceof CMM.Absyn.Type_bool)
    {
       CMM.Absyn.Type_bool _type_bool = (CMM.Absyn.Type_bool) foo;
       render("Type_bool");
    }
    if (foo instanceof CMM.Absyn.Type_int)
    {
       CMM.Absyn.Type_int _type_int = (CMM.Absyn.Type_int) foo;
       render("Type_int");
    }
    if (foo instanceof CMM.Absyn.Type_double)
    {
       CMM.Absyn.Type_double _type_double = (CMM.Absyn.Type_double) foo;
       render("Type_double");
    }
    if (foo instanceof CMM.Absyn.Type_void)
    {
       CMM.Absyn.Type_void _type_void = (CMM.Absyn.Type_void) foo;
       render("Type_void");
    }
  }

  private static void sh(CMM.Absyn.ListId foo)
  {
     for (java.util.Iterator<String> it = foo.iterator(); it.hasNext();)
     {
       sh(it.next());
       if (it.hasNext())
         render(",");
     }
  }


  private static void pp(Integer n, int _i_) { buf_.append(n); buf_.append(" "); }
  private static void pp(Double d, int _i_) { buf_.append(d); buf_.append(" "); }
  private static void pp(String s, int _i_) { buf_.append(s); buf_.append(" "); }
  private static void pp(Character c, int _i_) { buf_.append("'" + c.toString() + "'"); buf_.append(" "); }
  private static void sh(Integer n) { render(n.toString()); }
  private static void sh(Double d) { render(d.toString()); }
  private static void sh(Character c) { render(c.toString()); }
  private static void sh(String s) { printQuoted(s); }
  private static void printQuoted(String s) { render("\"" + s + "\""); }
  private static void indent()
  {
    int n = _n_;
    while (n > 0)
    {
      buf_.append(" ");
      n--;
    }
  }
  private static void backup()
  {
     if (buf_.charAt(buf_.length() - 1) == ' ') {
      buf_.setLength(buf_.length() - 1);
    }
  }
  private static void trim()
  {
     while (buf_.length() > 0 && buf_.charAt(0) == ' ')
        buf_.deleteCharAt(0);
    while (buf_.length() > 0 && buf_.charAt(buf_.length()-1) == ' ')
        buf_.deleteCharAt(buf_.length()-1);
  }
  private static int _n_ = 0;
  private static StringBuilder buf_ = new StringBuilder(INITIAL_BUFFER_SIZE);
}

