package CMM;
import CMM.Absyn.*;
/** BNFC-Generated Abstract Visitor */
public class AbstractVisitor<R,A> implements AllVisitor<R,A> {
/* Program */
    public R visit(CMM.Absyn.PDefs p, A arg) { return visitDefault(p, arg); }
    public R visitDefault(CMM.Absyn.Program p, A arg) {
      throw new IllegalArgumentException(this.getClass().getName() + ": " + p);
    }
/* Def */
    public R visit(CMM.Absyn.DFun p, A arg) { return visitDefault(p, arg); }
    public R visitDefault(CMM.Absyn.Def p, A arg) {
      throw new IllegalArgumentException(this.getClass().getName() + ": " + p);
    }
/* Arg */
    public R visit(CMM.Absyn.ADecl p, A arg) { return visitDefault(p, arg); }
    public R visitDefault(CMM.Absyn.Arg p, A arg) {
      throw new IllegalArgumentException(this.getClass().getName() + ": " + p);
    }
/* Stm */
    public R visit(CMM.Absyn.SExp p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.SInit p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.SWhile p, A arg) { return visitDefault(p, arg); }
    public R visitDefault(CMM.Absyn.Stm p, A arg) {
      throw new IllegalArgumentException(this.getClass().getName() + ": " + p);
    }
/* Exp */
    public R visit(CMM.Absyn.EBool p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.EInt p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.EDouble p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.EId p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.EApp p, A arg) { return visitDefault(p, arg); }







    public R visitDefault(CMM.Absyn.Exp p, A arg) {
      throw new IllegalArgumentException(this.getClass().getName() + ": " + p);
    }
/* BoolLit */
    public R visit(CMM.Absyn.LTrue p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.LFalse p, A arg) { return visitDefault(p, arg); }
    public R visitDefault(CMM.Absyn.BoolLit p, A arg) {
      throw new IllegalArgumentException(this.getClass().getName() + ": " + p);
    }
/* Type */
    public R visit(CMM.Absyn.Type_bool p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.Type_int p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.Type_double p, A arg) { return visitDefault(p, arg); }
    public R visit(CMM.Absyn.Type_void p, A arg) { return visitDefault(p, arg); }
    public R visitDefault(CMM.Absyn.Type p, A arg) {
      throw new IllegalArgumentException(this.getClass().getName() + ": " + p);
    }

}
