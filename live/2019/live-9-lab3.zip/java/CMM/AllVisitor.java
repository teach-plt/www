package CMM;

import CMM.Absyn.*;

/** BNFC-Generated All Visitor */
public interface AllVisitor<R,A> extends
  CMM.Absyn.Program.Visitor<R,A>,
  CMM.Absyn.Def.Visitor<R,A>,
  CMM.Absyn.Arg.Visitor<R,A>,
  CMM.Absyn.Stm.Visitor<R,A>,
  CMM.Absyn.Exp.Visitor<R,A>,
  CMM.Absyn.BoolLit.Visitor<R,A>,
  CMM.Absyn.Type.Visitor<R,A>
{}
