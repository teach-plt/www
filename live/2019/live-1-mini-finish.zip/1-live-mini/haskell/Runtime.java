class Runtime {

  static void print(int i) {
    System.out.println(i);
  }

  static void print(double d) {
    System.out.println(d);
  }

}
