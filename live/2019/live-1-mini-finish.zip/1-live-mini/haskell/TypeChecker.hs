{-# LANGUAGE LambdaCase #-}

-- | Simple type checker for MiniJS.
--
--   Ensures that a variable is never used at different types.

module TypeChecker where

import Data.Map (Map)
import qualified Data.Map as Map

import MiniJS.Abs
import Types

-- | Typing environments (contexts) map variables to types.

type Cxt = Map Var Type

-- | Type check a program.
--   Returns the typing of the variables.

typeCheck :: Program -> Cxt
typeCheck (Prg ss) = __TODO__

-- | Compute (infer) the type of an expression.

infer :: Cxt -> Exp -> Type
infer cxt = \case

  EVar    x    -> __TODO__
  EInt    i    -> __TODO__
  EDouble d    -> __TODO__
  ETimes e1 e2 -> __TODO__
  EDiv   e1 e2 -> __TODO__
  EPlus  e1 e2 -> __TODO__
  EMinus e1 e2 -> __TODO__

-- | Check that a statement is type-correct.
--
--   Variables cannot be assigned an expression of a different type
--   than the first time they were assigned.

check :: Cxt -> Stm -> Cxt
check cxt = \case

  SAssign x e -> __TODO__
  SPrint e    -> __TODO__


-- | Check a sequence of statements.

checks :: Cxt -> [Stm] -> Cxt
checks = foldl check


-- * Operation on the context

-- | Insert a new binding into the context.
--   If the variable is already bound, ensure that it has the same type.

insertVar :: Var -> Type -> Cxt -> Cxt
insertVar x t cxt =
  case Map.lookup x cxt of
    Nothing -> Map.insert x t cxt
    Just t' -> if t == t' then cxt else error $ "invalid assignment"


__TODO__ = undefined
