{-# LANGUAGE LambdaCase #-}

module Interpreter where

import Control.Monad
import Control.Monad.State

import Data.Maybe
import Data.Map (Map)
import qualified Data.Map as Map

import CMM.Abs
import CMM.Print
import CMM.ErrM

-- | Environment.
type Env   = [Block]
type Block = Map Id Val

data Val
  = VInt Integer
  | VVoid

type Sig = Map Id Def

-- | Interpreter state.
data St = St
  { stSig :: Sig
  , stEnv :: Env
  }

-- | Interpreter monad.
type Eval = StateT St IO

interpret :: Program -> IO ()
interpret (PDefs ds) = do
  let sig    = Map.fromList $ map (\ d@(DFun _ f _ _) -> (f,d)) ds
  let initSt = St { stSig = sig, stEnv = [] }

  case Map.lookup (Id "main") sig of
    Just (DFun _ _ _ ss) -> flip evalStateT initSt $ do
      newBlock Map.empty
      mapM_ evalStm ss

evalStm :: Stm -> Eval ()
evalStm = \case
  SInit t x e -> do
    v <- evalExp e
    addBind x v
  SExp e -> do
    v <- evalExp e
    return ()

evalExp :: Exp -> Eval Val
evalExp = \case
  EInt i -> return $ VInt i
  EId  x -> lookupVal x
  EApp (Id "printInt") [e] -> do
    VInt i <- evalExp e
    liftIO $ print i
    return $ VVoid


-- * Auxiliary functions

newBlock :: Block -> Eval ()
newBlock block = modify $ \ st -> st { stEnv = block : stEnv st }

addBind :: Id -> Val -> Eval ()
addBind x v = do
  (block:env) <- gets stEnv
  modify $ \ st -> st { stEnv = Map.insert x v block : env }

lookupVal :: Id -> Eval Val
lookupVal x = do
  env <- gets stEnv
  case mapMaybe (Map.lookup x) env of
    (v:_) -> return v
