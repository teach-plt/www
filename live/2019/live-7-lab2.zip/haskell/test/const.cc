int main () {
  int x = 3;
  printInt (x);
}
