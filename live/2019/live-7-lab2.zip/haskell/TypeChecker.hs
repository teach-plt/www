{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE FlexibleInstances, MultiParamTypeClasses, TypeSynonymInstances #-}

module TypeChecker where

import Control.Monad
import Control.Monad.Except
import Control.Monad.State

import Data.Map (Map)
import qualified Data.Map as Map
import Data.Maybe

import CMM.Abs
import CMM.Print
import CMM.ErrM

-- | Function types.
data FunType = FunType Type [Type]

-- | Typing contexts.
type Cxt   = [Block]
type Block = Map Id Type

-- | Type checker state.
data St = St
  { stCxt :: Cxt
  }

-- | Type checking monad.
type Check = StateT St Err

typecheck :: Program -> Err ()
typecheck (PDefs ds) = do
  mapM_ checkDef ds `evalStateT` initSt
  where
  initSt = St { stCxt = [] }

checkDef :: Def -> Check ()
checkDef (DFun t (Id "main") [] ss) = do
  put $ St { stCxt = [Map.empty] }
  checkStms ss

-- checkStms :: [Stm] -> Cxt -> Err ((), Cxt)
-- checkStms [] cxt = return cxt
-- checkStms (s : ss) cxt = do
--   (_, cxt')  <- checkStms s cxt
--   (_, cxt'') <- checkStms ss cxt'
--   return ((), cxt'')

checkStms :: [Stm] -> StateT St Err ()
checkStms = mapM_ checkStm
-- checkStms [] = return ()
-- checkStms (s : ss) = do
--   checkStm s
--   checkStm ss

checkStm :: Stm -> Check ()
checkStm = \case

  SInit t x e -> do
    checkExp e t
    addDecl x t

  SExp e -> do
    t <- inferExp e
    return ()

inferExp :: Exp -> Check Type
inferExp = \case
  EInt i -> return Type_int
  EId  x -> lookupType x
  EApp (Id "printInt") [e] -> do
    checkExp e Type_int
    return $ Type_void

checkExp :: Exp -> Type -> Check ()
checkExp e t = do
  t' <- inferExp e
  subType t' t


-- * Auxiliary functions

subType :: Type -> Type -> Check ()
subType Type_int Type_double = return ()
subType t1 t2 = unless (t1 == t2) $
  throwError $ unwords
    [ "expected expression of type"
    , printTree t1
    , "but found expression of type"
    , printTree t2
    ]

lookupType :: Id -> Check Type
lookupType x = do
  cxt <- gets stCxt
  case mapMaybe (Map.lookup x) cxt of
    []     -> throwError $ unwords [ "unbound variable", printTree x ]
    (t:ts) -> return t

addDecl :: Id -> Type -> Check ()
addDecl x t = do
  (block:cxt) <- gets stCxt
  case Map.lookup x block of
    Just{}  -> throwError $ unwords [ "variable", printTree x, "declared twice" ]
    Nothing -> modify $ \ st -> st { stCxt = Map.insert x t block : cxt }

newBlock :: Block -> Check ()
newBlock block = do
  modify $ \ st -> st { stCxt = block : stCxt st }

lookupFun :: Id -> Check FunType
lookupFun (Id x) = case x of
  "printInt" -> return $ FunType Type_void [Type_int]


instance MonadError String Err where
  throwError = Bad
  catchError = undefined
