import java.util.*;
import CMM.Absyn.*;

public class Interpreter {

  // signature
  private Map<String,DFun> sig;

  // environment
  private List<Map<String,Value>> env;

  // entrypoint
  public void interpret(Program p) {
    p.accept(new ProgramVisitor (), null);
    // throw new RuntimeException("Not yet an interpreter");
  }

  public class ProgramVisitor implements Program.Visitor<Void,Void>
  {
    public Void visit(CMM.Absyn.PDefs p, Void arg)
    {
      /* Add all definitions to the signature */
      sig = new TreeMap();
      for (Def d: p.listdef_) {
        DFun d1 = (DFun) d;
        sig.put(d1.id_, d1);
        // d.accept(new DefVisitor(), null);
      }

      /* Find main function */
      DFun main = sig.get("main");
      if (main == null) throw new RuntimeException("Impossible: main function missing");

      // Initialize environment
      env = new LinkedList ();
      env.add(new TreeMap());

      // Execute the function body
      try {
        for (Stm s: main.liststm_)
          s.accept(new StmVisitor(), null);
      } catch (ReturnException e) {}

      return null;
    }
  }
  public class DefVisitor implements Def.Visitor<Void,Void>
  {
    public Void visit(CMM.Absyn.DFun p, Void arg)
    { /* Code For DFun Goes Here */
      // p.type_.accept(new TypeVisitor<Void,Void>(), arg);
      //p.id_;
      for (Arg x: p.listarg_)
      { /* ... */ }
      for (Stm x: p.liststm_)
      { /* ... */ }
      return null;
    }
  }

  ////////////////////////////// Statements //////////////////////////////

  public class StmVisitor implements Stm.Visitor<Void,Void>
  {
    public Void visit(CMM.Absyn.SExp p, Void arg)
    {
      Value v = p.exp_.accept(new ExpVisitor(), arg);
      return null;
    }

    public Void visit(CMM.Absyn.SInit p, Void arg)
    {
      Value v = p.exp_.accept(new ExpVisitor(), arg);
      newVar (p.id_, v);
      return null;
    }

    // public Void visit(CMM.Absyn.SReturn p, Void arg)
    // {
    //   throw new ReturnException(p.exp_.accept(new ExpVisitor(), arg));
    // }
  }

  ////////////////////////////// Expressions //////////////////////////////

  public class ExpVisitor implements Exp.Visitor<Value,Void>
  {
    public Value visit(CMM.Absyn.EBool p, Void arg)
    {
      throw new TypeException ("not yet implemented");
    }

    public Value visit(CMM.Absyn.EInt p, Void arg)
    { /* Code For EInt Goes Here */
      return new VInt(p.integer_);
    }

    public Value visit(CMM.Absyn.EDouble p, Void arg)
    { //p.double_;
      throw new TypeException ("not yet implemented");
    }

    public Value visit(CMM.Absyn.EId p, Void arg)
    {
      return lookupVar(p.id_);
    }

    public Value visit(CMM.Absyn.EApp p, Void arg)
    { /* Code For EApp Goes Here */
      if (p.id_.equals("printInt")) {
        VInt v = (VInt) p.listexp_.get(0).accept (new ExpVisitor(), null);
        System.out.println (v.value);
      } else {
        for (Exp e : p.listexp_)
        { /* ... */ }

        // Execute function body

      }
      return new VVoid();
    }
  }

  public Value lookupVar (String x) {
    for (Map<String,Value> b : env) {
      Value v = b.get(x);
      if (v != null) return v;
    }
    throw new RuntimeException ("unbound variable " + x);
  }

  public void newVar (String x, Value v) {
    Map<String,Value> b = env.get(0);
    b.put(x,v);
  }
}
