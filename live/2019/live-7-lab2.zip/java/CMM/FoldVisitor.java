package CMM;

import CMM.Absyn.*;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

/** BNFC-Generated Fold Visitor */
public abstract class FoldVisitor<R,A> implements AllVisitor<R,A> {
    public abstract R leaf(A arg);
    public abstract R combine(R x, R y, A arg);

/* Program */
    public R visit(CMM.Absyn.PDefs p, A arg) {
      R r = leaf(arg);
      for (Def x : p.listdef_)
      {
        r = combine(x.accept(this, arg), r, arg);
      }
      return r;
    }

/* Def */
    public R visit(CMM.Absyn.DFun p, A arg) {
      R r = leaf(arg);
      r = combine(p.type_.accept(this, arg), r, arg);
      for (Arg x : p.listarg_)
      {
        r = combine(x.accept(this, arg), r, arg);
      }
      for (Stm x : p.liststm_)
      {
        r = combine(x.accept(this, arg), r, arg);
      }
      return r;
    }

/* Arg */
    public R visit(CMM.Absyn.ADecl p, A arg) {
      R r = leaf(arg);
      r = combine(p.type_.accept(this, arg), r, arg);
      return r;
    }

/* Stm */
    public R visit(CMM.Absyn.SExp p, A arg) {
      R r = leaf(arg);
      r = combine(p.exp_.accept(this, arg), r, arg);
      return r;
    }
    public R visit(CMM.Absyn.SInit p, A arg) {
      R r = leaf(arg);
      r = combine(p.type_.accept(this, arg), r, arg);
      r = combine(p.exp_.accept(this, arg), r, arg);
      return r;
    }

/* Exp */
    public R visit(CMM.Absyn.EBool p, A arg) {
      R r = leaf(arg);
      r = combine(p.boollit_.accept(this, arg), r, arg);
      return r;
    }
    public R visit(CMM.Absyn.EInt p, A arg) {
      R r = leaf(arg);
      return r;
    }
    public R visit(CMM.Absyn.EDouble p, A arg) {
      R r = leaf(arg);
      return r;
    }
    public R visit(CMM.Absyn.EId p, A arg) {
      R r = leaf(arg);
      return r;
    }
    public R visit(CMM.Absyn.EApp p, A arg) {
      R r = leaf(arg);
      for (Exp x : p.listexp_)
      {
        r = combine(x.accept(this, arg), r, arg);
      }
      return r;
    }

/* BoolLit */
    public R visit(CMM.Absyn.LTrue p, A arg) {
      R r = leaf(arg);
      return r;
    }
    public R visit(CMM.Absyn.LFalse p, A arg) {
      R r = leaf(arg);
      return r;
    }

/* Type */
    public R visit(CMM.Absyn.Type_bool p, A arg) {
      R r = leaf(arg);
      return r;
    }
    public R visit(CMM.Absyn.Type_int p, A arg) {
      R r = leaf(arg);
      return r;
    }
    public R visit(CMM.Absyn.Type_double p, A arg) {
      R r = leaf(arg);
      return r;
    }
    public R visit(CMM.Absyn.Type_void p, A arg) {
      R r = leaf(arg);
      return r;
    }


}
