package CMM;
import CMM.Absyn.*;
/** BNFC-Generated Composition Visitor
*/

public class ComposVisitor<A> implements
  CMM.Absyn.Program.Visitor<CMM.Absyn.Program,A>,
  CMM.Absyn.Def.Visitor<CMM.Absyn.Def,A>,
  CMM.Absyn.Arg.Visitor<CMM.Absyn.Arg,A>,
  CMM.Absyn.Stm.Visitor<CMM.Absyn.Stm,A>,
  CMM.Absyn.Exp.Visitor<CMM.Absyn.Exp,A>,
  CMM.Absyn.BoolLit.Visitor<CMM.Absyn.BoolLit,A>,
  CMM.Absyn.Type.Visitor<CMM.Absyn.Type,A>
{
/* Program */
    public Program visit(CMM.Absyn.PDefs p, A arg)
    {
      ListDef listdef_ = new ListDef();
      for (Def x : p.listdef_)
      {
        listdef_.add(x.accept(this,arg));
      }
      return new CMM.Absyn.PDefs(listdef_);
    }
/* Def */
    public Def visit(CMM.Absyn.DFun p, A arg)
    {
      Type type_ = p.type_.accept(this, arg);
      String id_ = p.id_;
      ListArg listarg_ = new ListArg();
      for (Arg x : p.listarg_)
      {
        listarg_.add(x.accept(this,arg));
      }
      ListStm liststm_ = new ListStm();
      for (Stm x : p.liststm_)
      {
        liststm_.add(x.accept(this,arg));
      }
      return new CMM.Absyn.DFun(type_, id_, listarg_, liststm_);
    }
/* Arg */
    public Arg visit(CMM.Absyn.ADecl p, A arg)
    {
      Type type_ = p.type_.accept(this, arg);
      String id_ = p.id_;
      return new CMM.Absyn.ADecl(type_, id_);
    }
/* Stm */
    public Stm visit(CMM.Absyn.SExp p, A arg)
    {
      Exp exp_ = p.exp_.accept(this, arg);
      return new CMM.Absyn.SExp(exp_);
    }    public Stm visit(CMM.Absyn.SInit p, A arg)
    {
      Type type_ = p.type_.accept(this, arg);
      String id_ = p.id_;
      Exp exp_ = p.exp_.accept(this, arg);
      return new CMM.Absyn.SInit(type_, id_, exp_);
    }
/* Exp */
    public Exp visit(CMM.Absyn.EBool p, A arg)
    {
      BoolLit boollit_ = p.boollit_.accept(this, arg);
      return new CMM.Absyn.EBool(boollit_);
    }    public Exp visit(CMM.Absyn.EInt p, A arg)
    {
      Integer integer_ = p.integer_;
      return new CMM.Absyn.EInt(integer_);
    }    public Exp visit(CMM.Absyn.EDouble p, A arg)
    {
      Double double_ = p.double_;
      return new CMM.Absyn.EDouble(double_);
    }    public Exp visit(CMM.Absyn.EId p, A arg)
    {
      String id_ = p.id_;
      return new CMM.Absyn.EId(id_);
    }    public Exp visit(CMM.Absyn.EApp p, A arg)
    {
      String id_ = p.id_;
      ListExp listexp_ = new ListExp();
      for (Exp x : p.listexp_)
      {
        listexp_.add(x.accept(this,arg));
      }
      return new CMM.Absyn.EApp(id_, listexp_);
    }
/* BoolLit */
    public BoolLit visit(CMM.Absyn.LTrue p, A arg)
    {
      return new CMM.Absyn.LTrue();
    }    public BoolLit visit(CMM.Absyn.LFalse p, A arg)
    {
      return new CMM.Absyn.LFalse();
    }
/* Type */
    public Type visit(CMM.Absyn.Type_bool p, A arg)
    {
      return new CMM.Absyn.Type_bool();
    }    public Type visit(CMM.Absyn.Type_int p, A arg)
    {
      return new CMM.Absyn.Type_int();
    }    public Type visit(CMM.Absyn.Type_double p, A arg)
    {
      return new CMM.Absyn.Type_double();
    }    public Type visit(CMM.Absyn.Type_void p, A arg)
    {
      return new CMM.Absyn.Type_void();
    }
}
