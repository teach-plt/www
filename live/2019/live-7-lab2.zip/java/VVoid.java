public class VVoid extends Value {
  public boolean equals(Object o) {
    return (o instanceof VVoid);
  }
}
