console.log (0);
x = 5; 
console.log (x);
x = x + 3;
console.log (x);
