x = (1 + 2) * 2 - 5;
console.log (x);
y = 3.14159 * x;
y = (y + x) - x;
console.log (y);
