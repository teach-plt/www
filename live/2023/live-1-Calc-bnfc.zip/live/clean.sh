#!/bin/sh

make distclean
rm Main *.hi *.o *~
