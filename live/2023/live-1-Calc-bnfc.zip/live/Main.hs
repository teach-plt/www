import Calc.Abs   ( Exp(..) )
import Calc.Par   ( pExp, myLexer )
import Calc.Print ( printTree )

eval :: Exp -> Integer
eval e =
  case e of
    EInt   i     -> i
    EPlus  e1 e2 -> eval e1 + eval e2
    ETimes e1 e2 -> eval e1 * eval e2
    EMinus e1 e2 -> eval e1 - eval e2
    EDiv   e1 e2 -> eval e1 `div` eval e2
  where
    nyi = error $ "not yet implemented: eval " ++ show e

main :: IO ()
main = do
  -- Read from stdin, lex, parse
  putStr "Calc> "
  res <- pExp . myLexer <$> getContents
  case res of
    Left err -> putStrLn err
    Right  e -> print $ eval e
