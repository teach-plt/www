import Calc.Abs   -- ( Exp(..), Atm(..) )
import Calc.Par   ( pExp, myLexer )
import Calc.Print ( printTree )

eval :: Exp -> Integer
eval e =
  case e of
    EAdd e1 e2 -> eval e1 + eval e2
    ESub e1 e2 -> eval e1 - eval e2
    EMul e1 e2 -> eval e1 * eval e2
    EDiv e1 e2 -> eval e1 `div` eval e2
    EInt i     -> i

main :: IO ()
main = do
  -- Read from stdin, lex, parse
  putStr "Calc> "
  res <- pExp . myLexer <$> getContents
  case res of
    Left err -> putStrLn err
    Right  e -> print $ eval e

-- e0 :: Exp
-- e0 = ESub (EInt 5) (ESub (EInt 3) (EInt 1))
-- e1 :: Exp
-- e1 = ESub (ESub (EInt 5) (EInt 3)) (EInt 1)
