#!/usr/bin/env sh

rm -rf .stack-work Main *.hi *.o *~
make distclean
