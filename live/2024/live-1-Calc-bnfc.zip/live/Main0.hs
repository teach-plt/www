import Calc.Abs   -- ( Exp(..), Atm(..) )
import Calc.Par   ( pExp, myLexer )
import Calc.Print ( printTree )

eval :: Exp -> Integer
eval e =
  case e of
    ESub e1 e2 -> eval e1 - evalAtom e2
    EAtm  a    -> evalAtom a

evalAtom :: Atm -> Integer
evalAtom a = case a of
  EInt i -> i
  EPar e -> eval e

main :: IO ()
main = do
  -- Read from stdin, lex, parse
  putStr "Calc> "
  res <- pExp . myLexer <$> getContents
  case res of
    Left err -> putStrLn err
    Right  e -> print $ eval e

-- e0 :: Exp
-- e0 = ESub (EInt 5) (ESub (EInt 3) (EInt 1))
-- e1 :: Exp
-- e1 = ESub (ESub (EInt 5) (EInt 3)) (EInt 1)
