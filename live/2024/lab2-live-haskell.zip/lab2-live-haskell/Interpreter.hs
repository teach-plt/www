-- Programming Language Technology (Chalmers DAT151 / GU DIT231)
-- (C) 2022-24 Andreas Abel
-- All rights reserved.

{-# OPTIONS_GHC -Wno-unused-imports #-} -- Turn off unused import warning off in stub

module Interpreter where

import Control.Monad

import Data.Map (Map)
import qualified Data.Map as Map

import System.Exit (exitFailure)

import CMM.Abs (Id(..))
import CMM.Print

import Annotated

data Val
  = VInt Integer
  | VDouble Double
  | VBool Bool
  | VNull

type Sig = Map Id Def

type Env = [Block]
type Block = Map Id Val

emptyEnv :: Env
emptyEnv = [Map.empty]

interpret :: Program -> IO ()
interpret (PDefs ds) = do

  -- Make function table
  let sig = Map.fromList $ map (\ d@(DFun t x args ss) -> (x, d)) ds

  -- Find main function
  case Map.lookup (Id "main") sig of
    Just (DFun _ _ _ ss) -> do
      env <- execStms sig emptyEnv ss
      return ()

  -- nyi (PDefs ds)

execStms :: Sig -> Env -> [Stm] -> IO Env
execStms sig env = \case
  [] -> return env
  s : ss -> do
    env1 <- execStm sig env s
    env2 <- execStms sig env1 ss
    return env2

execStm :: Sig -> Env -> Stm -> IO Env
execStm sig env = \case
  SInit t x e -> do
    let env1 = addVar x VNull env
    (v, env2) <- evalExp sig env1 e
    env3 <- updateVar x v env2
    return env3
  SExp e t -> do
    (_v, env1) <- evalExp sig env e
    return env1
  s -> nyi s

evalExp :: Sig -> Env -> Exp -> IO (Val, Env)
evalExp sig env = \case
  EInt i -> return (VInt i, env)
  EId x -> do
    v <- lookupVar x env
    return (v, env)
  EI2D e -> do
    (VInt i, env1) <- evalExp sig env e
    return (VDouble $ fromIntegral i, env1)
  EApp f es -> do
    case f of
      Id "printDouble" -> do
        (VDouble v, env1) <- evalExp sig env (head es)
        print v
        return (VNull, env1)

-- * Auxiliary functions

nyi :: Print a => a -> IO b
nyi a = interpreterError $ unwords ["not yet implemented:", printTree a]

interpreterError :: String -> IO a
interpreterError s = do
  putStrLn $ unwords ["INTERPRETER ERROR:", s ]
  exitFailure

addVar :: Id -> Val -> Env -> Env
addVar = error "Censored"

updateVar :: Id -> Val -> Env -> IO Env
updateVar = error "Censored"

lookupVar :: Id -> Env -> IO Val
lookupVar = error "Censored"
