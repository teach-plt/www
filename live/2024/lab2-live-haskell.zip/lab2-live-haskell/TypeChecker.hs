-- Programming Language Technology (Chalmers DAT151 / GU DIT231)
-- (C) 2022-24 Andreas Abel
-- All rights reserved.

{-# OPTIONS_GHC -Wno-unused-imports #-} -- Turn off unused import warning off in stub

module TypeChecker where

import Control.Monad
import Control.Monad.Except

import Data.Functor
import Data.Map (Map)
import qualified Data.Map as Map

import CMM.Abs
import CMM.Print (Print, printTree)

import qualified Annotated as A

type TypeError = String

data FunType = FunType
  { resultType :: Type
  , argTypes   :: [Type]
  }

type Sig = Map Id FunType
type Cxt = [Block] -- nonempty
type Block = Map Id Type

typecheck :: Program -> Either TypeError A.Program
typecheck (PDefs ds) = do

  -- Pass 1: produce table of functions
  -- We need to check for duplicate functions
  sig <- buildMap $
     (Id "printDouble", FunType Type_void [Type_double]) :
     map (\ (DFun t x args _) -> (x, FunType t $ map (\ (ADecl t' _) -> t') args)) ds

  -- Pass 2: check all definitions
  ds' <- mapM (checkDef sig) ds

  -- Check for main
  case Map.lookup (Id "main") sig of
    Just (FunType Type_int []) -> pure ()
    _ -> throwError $ "no or wrong main"

  return (A.PDefs ds')

checkDef :: Sig -> Def -> Either TypeError A.Def
checkDef sig d@(DFun t x args ss) = do
  block <- buildMap $ map (\ (ADecl t' x') -> (x', t')) args
  let cxt = [block]
  (ss', _cxt) <- checkStms sig t cxt ss
  return $ A.DFun t x args ss'

checkStms :: Sig -> Type -> Cxt -> [Stm] -> Either TypeError ([A.Stm], Cxt)
checkStms sig returnType cxt = \case
  [] -> return ([], cxt)
  s : ss -> do
    (s', cxt1) <- checkStm sig returnType cxt s
    (ss', cxt2) <- checkStms sig returnType cxt1 ss
    return (s':ss', cxt2)

checkStm :: Sig -> Type -> Cxt -> Stm -> Either TypeError (A.Stm, Cxt)
checkStm sig returnType cxt = \case
  SInit t x e -> do
    cxt1 <- addVar x t cxt
    e' <- checkExp sig cxt1 e t
    return (A.SInit t x e', cxt1)
  SExp e -> do
    (e', t) <- inferExp sig cxt e
    return (A.SExp e' t, cxt)
  s -> nyi s

checkExp :: Sig -> Cxt -> Exp -> Type -> Either TypeError A.Exp
checkExp sig cxt e t = do
  (e', t') <- inferExp sig cxt e
  coerce t' t e'

coerce :: Type -> Type -> A.Exp -> Either TypeError A.Exp
coerce t1 t2 e = case (t1, t2) of
  _ | t1 == t2 -> return e
  (Type_int, Type_double) -> return $ A.EI2D e
  _ -> throwError "type mismatch"

inferExp :: Sig -> Cxt -> Exp -> Either TypeError (A.Exp, Type)
inferExp sig cxt = \case
  EInt i -> return (A.EInt i, Type_int)
  EId x  -> do
    t <- lookupVar x cxt
    return (A.EId x, t)
  EApp f es -> do
    case Map.lookup f sig of
      Nothing -> throwError "unbound function"
      Just (FunType t ts) -> do
        es' <- checkArgs sig cxt es ts
        return (A.EApp f es', t)


checkArgs :: Sig -> Cxt -> [Exp] -> [Type] -> Either TypeError [A.Exp]
checkArgs sig cxt = curry \case
  ([],[]) -> return []
  (e:es, t:ts) -> do
    e' <- checkExp sig cxt e t
    es' <- checkArgs sig cxt es ts
    return (e' : es')
  _ -> throwError "incorrect number of arguments"

-- * Auxiliary functions

nyi :: (MonadError TypeError m, Print a) => a -> m b
nyi a = throwError $ unwords ["not yet implemented:", printTree a]

buildMap :: [(Id, t)] -> Either TypeError (Map Id t)
buildMap decls = foldM addEntry Map.empty decls

addEntry :: Map Id t -> (Id, t) -> Either TypeError (Map Id t)
addEntry m (x, t) =
  case Map.lookup x m of
    Just{} -> throwError $ unwords ["duplicate declaration:", printTree x]
    Nothing -> return $ Map.insert x t m

addVar :: Id -> Type -> Cxt -> Either TypeError Cxt
addVar = error "Censored"

lookupVar :: Id -> Cxt -> Either TypeError Type
lookupVar = error "Censored"
