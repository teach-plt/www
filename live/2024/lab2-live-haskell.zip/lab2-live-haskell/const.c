#include <stdio.h>
#define printDouble(x) printf("%f\n",(double)x)

int main() {
  int x = 42;
  printDouble(x);
}
