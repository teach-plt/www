#!/usr/bin/env sh

rm -rf .stack-work stack*.yaml.lock Main *.hi *.o *~
make distclean
