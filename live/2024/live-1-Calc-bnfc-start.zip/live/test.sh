#!/usr/bin/env sh

stack run <<< "5 - 3 - 1"         # 1
# stack run <<< "1 + 2 * 3 + 4"     # 11
# stack run <<< "(1 - (2 - 3)) / 2" # 1

# EOF
