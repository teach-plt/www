import Calc.Abs   ( Exp(..) )
import Calc.Par   ( pExp, myLexer )
import Calc.Print ( printTree )

eval :: Exp -> Integer
eval e =
  case e of
    _ -> nyi
  where
    nyi = error $ "not yet implemented: eval " ++ show e

main :: IO ()
main = do
  -- Read from stdin, lex, parse
  putStr "Calc> "
  res <- pExp . myLexer <$> getContents
  case res of
    Left err -> putStrLn err
    Right  e -> print $ eval e
