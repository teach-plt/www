package Code;

import Code.Absyn.*;

/** BNFC-Generated All Visitor */
public interface AllVisitor<R,A> extends
  Code.Absyn.Ins.Visitor<R,A>
{}
